package com.netflix.discovery.converters.wrappers;

import javax.ws.rs.core.MediaType;

public interface CodecWrapperBase {

    String codecName();

    boolean support(MediaType mediaType);
}
