package com.netflix.discovery.shared.transport.jersey;

import com.sun.jersey.client.apache4.ApacheHttpClient4;

public interface EurekaJerseyClient {
    ApacheHttpClient4 getClient();

    void destroyResources();
}
