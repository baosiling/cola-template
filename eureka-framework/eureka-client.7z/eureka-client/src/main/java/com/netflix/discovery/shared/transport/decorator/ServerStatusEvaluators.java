package com.netflix.discovery.shared.transport.decorator;

import com.netflix.discovery.shared.transport.decorator.EurekaHttpClientDecorator.RequestType;


public class ServerStatusEvaluators {

    private static final ServerStatusEvaluator LEGACY_EVALUATOR = new ServerStatusEvaluator() {
        @Override
        public boolean accept(int statusCode, RequestType requestType) {
            if (statusCode >= 200 && statusCode <= 300 || statusCode == 302) {
                return true;
            } else if (requestType == RequestType.Register && statusCode == 404) {
                return true;
            } else if (requestType == RequestType.SendHeartBeat && statusCode == 404) {
                return true;
            } else if (requestType == RequestType.Cancel) {
                return true;
            } else if (requestType == RequestType.GetDelta && (statusCode == 403 || statusCode == 404)) {
                return true;
            }
            return false;
        }
    };

    private static final ServerStatusEvaluator HTTP_SUCCESS_EVALUATOR = new ServerStatusEvaluator() {
        @Override
        public boolean accept(int statusCode, RequestType requestType) {
            return statusCode >= 200 && statusCode < 300;
        }
    };

    private ServerStatusEvaluators() {

    }

    /**
     * Evaluator rules implemented in com.netflix.discovery.DiscoveryClient#isOk(...) method
     * @return
     */
    public static ServerStatusEvaluator legacyEvaluator(){
        return LEGACY_EVALUATOR;
    }

    /**
     * An evaluator that only care about http 2xx response
     * @return
     */
    public static ServerStatusEvaluator httpSuccessEvaluator() {
        return HTTP_SUCCESS_EVALUATOR;
    }


}
