package com.netflix.discovery.shared.transport.decorator;

import com.netflix.discovery.shared.transport.decorator.EurekaHttpClientDecorator.RequestType;

/**
 * HTTP status code evaluator, that can be used to make a decision whether it makes sense to
 * immediately retry a request on another server or stick to the current one.
 * Registration requests are critical to complete as soon as possible, so any server error
 * should be followed by retry on another one. Registry fetch/delta fetch should stick to the
 * same server, to avoid delta hash code mismatches.
 * See https://github.com/Netflix/eureka/issues/628.
 */
public interface ServerStatusEvaluator {
    boolean accept(int statusCode, RequestType requestType);
}
