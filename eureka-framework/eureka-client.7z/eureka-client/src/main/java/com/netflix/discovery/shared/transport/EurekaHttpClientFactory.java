package com.netflix.discovery.shared.transport;

/**
 * A top level factory to create http clients for application/eurekaClient use
 */
public interface EurekaHttpClientFactory {

    EurekaHttpClient newClient();

    void shutdown();
}
