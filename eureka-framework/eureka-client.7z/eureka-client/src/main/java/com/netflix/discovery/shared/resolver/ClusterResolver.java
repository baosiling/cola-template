package com.netflix.discovery.shared.resolver;

import java.util.List;

public interface ClusterResolver<T extends EurekaEndpoint> {

    String getRegion();

    List<T> getClusterEndpoints();
}
