package com.netflix.appinfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * @description:
 * @author: wangzhx
 * @create: 2020-09-06 14:21
 */
//TODO
public class AmazonInfo implements DataCenterInfo, UniqueIdentifier {



    public enum MetaDataKey{
        availabilityZone("availability-zone", "placement/"),
        spotInstanceAction("instance-action", "spot/"),
        localIpv4("local-ipv4"),;

        protected String name;
        protected String path;

        MetaDataKey(String name) {
            this(name, "");
        }

        MetaDataKey(String name, String path) {
            this.name = name;
            this.path = path;
        }

        public String getName(){
            return name;
        }
    }

    private Map<String, String> metadata;

    @Override
    public Name getName() {
        return null;
    }

    @Override
    public String getId() {
        return null;
    }

    public String get(MetaDataKey key){
        return null;
    }

    @JsonProperty("metadata")
    public Map<String, String> getMetadata(){
        return metadata;
    }

    /**
     * Set AWS metadata.
     *
     * @param metadataMap
     *            the map containing AWS metadata.
     */
    public void setMetadata(Map<String, String> metadataMap) {
        this.metadata = metadataMap;
    }
}