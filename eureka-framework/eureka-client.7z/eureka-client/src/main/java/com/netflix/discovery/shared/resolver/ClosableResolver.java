package com.netflix.discovery.shared.resolver;

public interface ClosableResolver<T extends EurekaEndpoint> extends ClusterResolver<T> {
    void shutdown();
}
