package com.netflix.appinfo;

public interface RefreshableInstanceConfig {

    String resolveDefaultAddress(boolean refresh);
}
