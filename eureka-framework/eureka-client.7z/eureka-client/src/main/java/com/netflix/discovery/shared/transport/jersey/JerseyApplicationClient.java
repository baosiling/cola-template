package com.netflix.discovery.shared.transport.jersey;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

import java.util.Map;

public class JerseyApplicationClient extends AbstractJerseyEurekaHttpClient {

    private final Map<String, String> additionalHeaders;

    public JerseyApplicationClient(Client jerseyClient, String serviceUrl, Map<String, String> additionalHeaders) {
        super(jerseyClient, serviceUrl);
        this.additionalHeaders = additionalHeaders;
    }

    @Override
    protected void addExtraHeaders(WebResource.Builder webResource) {
        if(additionalHeaders != null) {
            for(Map.Entry<String, String> entry : additionalHeaders.entrySet()){
                webResource.header(entry.getKey(), entry.getValue());
            }
        }
    }
}
