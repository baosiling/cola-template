package com.netflix.appinfo;

public class CloudInstanceConfig {
}
