package com.netflix.discovery.shared.transport;

import com.netflix.discovery.shared.resolver.EurekaEndpoint;

/**
 * A low level client factory interface. Not advised to be used by top level consumers.
 */
public interface TransportClientFactory {

    EurekaHttpClient newClient(EurekaEndpoint eurekaEndpoint);

    void shutdown();
}
