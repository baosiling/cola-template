package com.netflix.discovery.shared.transport;

import java.util.concurrent.atomic.AtomicReference;

public class TransportUtils {

    private TransportUtils() {

    }

    public static EurekaHttpClient getOrSetAnotherClient(AtomicReference<EurekaHttpClient> eurekaHttpClientRef,
                                                         EurekaHttpClient another) {
        EurekaHttpClient existing = eurekaHttpClientRef.get();
        if(eurekaHttpClientRef.compareAndSet(null, another)){
            return another;
        }
        another.shutdown();
        return existing;
    }

    public static void shutdown(EurekaHttpClient eurekaHttpClient) {
        if(eurekaHttpClient != null){
            eurekaHttpClient.shutdown();
        }
    }
}
