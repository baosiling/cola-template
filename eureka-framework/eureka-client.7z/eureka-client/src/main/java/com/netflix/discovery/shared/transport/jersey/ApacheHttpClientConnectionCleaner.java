package com.netflix.discovery.shared.transport.jersey;

import com.netflix.servo.monitor.*;
import com.sun.jersey.client.apache4.ApacheHttpClient4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A periodic process running in background cleaning Apache http client connection pool out
 * of idle connections.
 */
public class ApacheHttpClientConnectionCleaner {

    private static final Logger logger = LoggerFactory.getLogger(ApacheHttpClientConnectionCleaner.class);

    private static final int HTTP_CONNECTION_CLEANER_INTERVAL_MS = 30 * 1000;

    private final ScheduledExecutorService eurekaConnCleaner =
            Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {

                private final AtomicInteger threadNumber = new AtomicInteger(1);

                @Override
                public Thread newThread(Runnable r) {
                    Thread thread = new Thread(r, "Apache-HttpClient-Conn-Cleaner" + threadNumber.incrementAndGet());
                    thread.setDaemon(true);
                    return thread;
                }
            });

    private final ApacheHttpClient4 apacheHttpClient;

    private final BasicTimer executionTimeStats;
    private final Counter cleanupFailed;

    public ApacheHttpClientConnectionCleaner(ApacheHttpClient4 apacheHttpClient, final long connectionIdleTimeout) {
        this.apacheHttpClient = apacheHttpClient;
        this.eurekaConnCleaner.scheduleWithFixedDelay(
                ()->cleanIdle(connectionIdleTimeout),
                HTTP_CONNECTION_CLEANER_INTERVAL_MS,
                HTTP_CONNECTION_CLEANER_INTERVAL_MS,
                TimeUnit.MILLISECONDS
        );

        MonitorConfig.Builder monitorConfigBuilder = MonitorConfig.builder("Eureka-Connection-Cleaner-Time");
        executionTimeStats = new BasicTimer(monitorConfigBuilder.build());
        cleanupFailed = new BasicCounter(MonitorConfig.builder("Eureka-Connection-Cleaner-Failure").build());
        try{
            Monitors.registerObject(this);
        }catch(Exception e){
            logger.error("Unable to register with servo.", e);
        }
    }

    public void shutdown(){
        cleanIdle(0);
        eurekaConnCleaner.shutdown();
        Monitors.unregisterObject(this);
    }

    public void cleanIdle(long delayMs) {
        Stopwatch start = executionTimeStats.start();
        try{
            apacheHttpClient.getClientHandler().getHttpClient()
                    .getConnectionManager()
                    .closeIdleConnections(delayMs, TimeUnit.SECONDS);
        } catch(Throwable e) {
            logger.error("Cannot clean connection", e);
            cleanupFailed.increment();
        } finally {
            if(null != start) {
                start.stop();
            }
        }
    }

}
