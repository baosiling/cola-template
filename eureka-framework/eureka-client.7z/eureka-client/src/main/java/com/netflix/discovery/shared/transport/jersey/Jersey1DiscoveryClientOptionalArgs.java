package com.netflix.discovery.shared.transport.jersey;

import com.netflix.discovery.AbstractDiscoveryClientOptionalArgs;
import com.sun.jersey.api.client.filter.ClientFilter;

public class Jersey1DiscoveryClientOptionalArgs extends AbstractDiscoveryClientOptionalArgs<ClientFilter> {

}
