package com.netflix.discovery;

/**
 * Maker interface for Eureka evnets
 *
 * @see {@link EurekaEventListener}
 */
public interface EurekaEvent {
}
